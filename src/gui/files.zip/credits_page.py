# -*- coding: utf-8 -*-
"""
Page "Crédits" : visionneuse type artbook pour le dossier
``credit_du_logiciel/`` (photos + vidéos souvenirs classées par
événement, un dossier = un événement).

Règles de navigation demandées :
  - chaque dossier devient un onglet ; le nom de l'onglet est le seul
    indice de "dans quel dossier on est" ;
  - à l'intérieur d'un dossier, les fichiers défilent dans un ordre
    fixe (chronologique) : pas d'accès aléatoire à une image ;
  - "Suivant" sur le dernier fichier d'un dossier enchaîne
    automatiquement sur le premier fichier du dossier suivant (et
    inversement pour "Précédent") ;
  - cliquer directement sur un onglet saute en revanche tout de
    suite au dossier voulu.

Rien de tout cela (scan du dossier, décodage des images) ne se fait
sur le thread d'interface : avec ~790 Mo de photos/vidéos, cliquer
sur "Crédits" ne doit jamais figer la fenêtre. Le scan tourne dans un
QThread dédié, et chaque image affichée est décodée/réduite dans un
second QThread persistant qui traite les demandes en file ; l'image
suivante est préchargée pendant que l'image courante est affichée.
Les vidéos ne sont pas préchargées : QMediaPlayer les décode déjà de
façon asynchrone.

Réglages rapides
----------------
CREDITS_EDIT_MODE : mettre à False avant la publication finale.
Tant que c'est True, chaque photo/vidéo peut recevoir une légende
écrite depuis l'interface (enregistrée dans captions.json à la
racine du dossier credit_du_logiciel). Une fois à False, les
légendes restent visibles mais ne sont plus modifiables.

Chiffrement des médias : volontairement PAS traité ici. Un simple
"empêcher l'usage des photos hors logiciel" n'a pas de solution
étanche (le logiciel doit bien les déchiffrer pour les afficher), et
c'est un chantier à part (il faudrait a minima installer le paquet
``cryptography``, absent du venv actuel). A prevoir separement.
"""

from __future__ import annotations

import json
from collections import OrderedDict
from pathlib import Path

from PySide6.QtCore import Qt, QObject, QThread, Signal, Slot, QSize, QTimer
from PySide6.QtGui import QImage, QPixmap, QFont
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame,
    QScrollArea, QSizePolicy, QStackedWidget, QTextEdit, QToolButton,
)

try:
    from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput
    from PySide6.QtMultimediaWidgets import QVideoWidget
    _MULTIMEDIA_OK = True
except Exception:
    _MULTIMEDIA_OK = False


# ============================================================================
# REGLAGES
# ============================================================================

# Mettre a False avant la publication finale du logiciel : desactive
# l'ecriture/modification des legendes depuis l'interface (lecture
# seule des legendes deja enregistrees).
CREDITS_EDIT_MODE = True

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"}
VIDEO_EXTS = {".mp4", ".mov", ".avi", ".mkv", ".webm"}

CAPTIONS_FILENAME = "captions.json"
ORDER_FILENAME = "ordre_albums.json"

_MAX_PIXMAP_CACHE = 14
_MAX_IMG_W, _MAX_IMG_H = 1600, 1000

_BG = "#0f1721"
_PANEL = "#101d2b"
_BORDER = "rgba(131, 154, 177, 90)"
_TEXT = "#edf5ff"
_TEXT_MUTED = "#8ea8bc"
_ACCENT = "#6bd18d"


def _credits_root() -> Path | None:
    """Racine du dossier credit_du_logiciel, cote du dossier src/."""
    here = Path(__file__).resolve()
    candidates = []
    if len(here.parents) > 2:
        candidates.append(here.parents[2])
    if len(here.parents) > 1:
        candidates.append(here.parents[1])
    for base in candidates:
        candidate = base / "credit_du_logiciel"
        if candidate.is_dir():
            return candidate
    return None


def _pretty_label(folder_name: str) -> str:
    label = folder_name.replace("_", " ").replace("-", " ").strip()
    return label[:1].upper() + label[1:] if label else folder_name


# ============================================================================
# SCAN DU DOSSIER (thread dedie, une fois par ouverture / actualisation)
# ============================================================================

class _AlbumScanWorker(QObject):
    finished = Signal(list, dict, str)  # albums, captions, erreur

    def __init__(self, root: Path):
        super().__init__()
        self.root = root

    @Slot()
    def run(self):
        try:
            albums = self._scan_albums()
            captions = self._load_captions()
            self.finished.emit(albums, captions, "")
        except Exception as exc:
            self.finished.emit([], {}, str(exc))

    def _load_captions(self) -> dict:
        captions_path = self.root / CAPTIONS_FILENAME
        if not captions_path.exists():
            return {}
        try:
            return json.loads(captions_path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _scan_albums(self):
        order_file = self.root / ORDER_FILENAME
        manual_order = []
        if order_file.exists():
            try:
                manual_order = json.loads(order_file.read_text(encoding="utf-8"))
            except Exception:
                manual_order = []

        albums = []
        for entry in sorted(self.root.iterdir()):
            if not entry.is_dir():
                continue

            items = []
            for f in entry.iterdir():
                ext = f.suffix.lower()
                if ext in IMAGE_EXTS:
                    kind = "image"
                elif ext in VIDEO_EXTS:
                    kind = "video"
                else:
                    continue
                try:
                    mtime = f.stat().st_mtime
                except OSError:
                    mtime = 0.0
                items.append({"path": str(f), "name": f.name, "type": kind, "mtime": mtime})

            if not items:
                continue

            items.sort(key=lambda it: (it["mtime"], it["name"]))

            albums.append({
                "key": entry.name,
                "label": _pretty_label(entry.name),
                "items": items,
                "first_mtime": items[0]["mtime"],
            })

        if manual_order:
            rank = {name: i for i, name in enumerate(manual_order)}
            albums.sort(key=lambda a: (rank.get(a["key"], len(manual_order)), a["first_mtime"]))
        else:
            albums.sort(key=lambda a: a["first_mtime"])

        return albums


# ============================================================================
# CHARGEMENT D'IMAGE (thread persistant, file de demandes)
# ============================================================================

class _ImageLoaderWorker(QObject):
    # QPixmap n'est fiable que sur le thread GUI (dependances a la
    # plateforme d'affichage) : on ne fait circuler que des QImage,
    # thread-safe, et la conversion en QPixmap se fait cote thread
    # principal, dans _on_image_ready.
    imageReady = Signal(str, int, int, QImage)  # album_key, item_index, requete, image
    failed = Signal(str, int, int, str)

    @Slot(str, int, int, str)
    def load(self, album_key, item_index, request_id, path_str):
        try:
            image = QImage(path_str)
            if image.isNull():
                self.failed.emit(album_key, item_index, request_id, "Image illisible")
                return
            if image.width() > _MAX_IMG_W or image.height() > _MAX_IMG_H:
                image = image.scaled(
                    _MAX_IMG_W, _MAX_IMG_H, Qt.KeepAspectRatio, Qt.SmoothTransformation
                )
            self.imageReady.emit(album_key, item_index, request_id, image)
        except Exception as exc:
            self.failed.emit(album_key, item_index, request_id, str(exc))


# ============================================================================
# WIDGET PRINCIPAL
# ============================================================================

class CreditsPage(QWidget):
    """
    Page "Crédits" : un onglet horizontal par dossier d'événement, et
    à l'intérieur, un défilement séquentiel photos/vidéos avec
    légende optionnelle.
    """

    requestImageLoad = Signal(str, int, int, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFocusPolicy(Qt.StrongFocus)

        self._root = _credits_root()
        self._albums = []
        self._captions = {}
        self._pixmap_cache = OrderedDict()   # (album_key, item_index) -> QPixmap
        self._album_index = 0
        self._item_index = 0
        self._request_seq = 0
        self._scanning = False
        self._loaded_once = False
        self._tab_buttons = []

        self._image_thread = None
        self._image_worker = None
        self._scan_thread = None
        self._scan_worker = None

        self._build_ui()
        self._start_image_loader()

    # ------------------------------------------------------------------
    # CONSTRUCTION DE L'INTERFACE
    # ------------------------------------------------------------------

    def _build_ui(self):
        self.setStyleSheet(f"background-color: {_BG};")

        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 22, 24, 20)
        outer.setSpacing(12)

        # --- En-tete ----------------------------------------------------
        header = QHBoxLayout()

        title = QLabel("Crédits")
        title.setStyleSheet(f"color:{_TEXT}; font-size:20px; font-weight:700;")
        header.addWidget(title)

        self.subtitle_label = QLabel("")
        self.subtitle_label.setStyleSheet(f"color:{_TEXT_MUTED}; font-size:12px;")
        header.addWidget(self.subtitle_label)
        header.addStretch()

        self.refresh_button = QPushButton("Actualiser")
        self.refresh_button.setCursor(Qt.PointingHandCursor)
        self.refresh_button.clicked.connect(self._start_scan)
        header.addWidget(self.refresh_button)

        outer.addLayout(header)

        # --- Bandeau d'onglets (un par dossier), defilant horizontalement
        self.tabs_scroll = QScrollArea()
        self.tabs_scroll.setWidgetResizable(True)
        self.tabs_scroll.setFixedHeight(46)
        self.tabs_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.tabs_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.tabs_scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")

        self.tabs_container = QWidget()
        self.tabs_container.setStyleSheet("background: transparent;")
        self.tabs_layout = QHBoxLayout(self.tabs_container)
        self.tabs_layout.setContentsMargins(2, 2, 2, 2)
        self.tabs_layout.setSpacing(6)
        self.tabs_layout.addStretch()
        self.tabs_scroll.setWidget(self.tabs_container)

        outer.addWidget(self.tabs_scroll)

        # --- Zone de contenu ---------------------------------------------
        content = QFrame()
        content.setObjectName("CreditsContentPanel")
        content.setStyleSheet(
            f"#CreditsContentPanel {{ background-color:{_PANEL}; "
            f"border: 1px solid {_BORDER}; border-radius: 14px; }}"
        )
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(18, 18, 18, 14)
        content_layout.setSpacing(10)

        self.stage = QStackedWidget()
        self.stage.setMinimumHeight(420)

        # Page "image"
        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setStyleSheet("background: transparent;")
        self.stage.addWidget(self.image_label)

        # Page "vidéo"
        video_page = QWidget()
        video_layout = QVBoxLayout(video_page)
        video_layout.setContentsMargins(0, 0, 0, 0)
        video_layout.setSpacing(6)

        if _MULTIMEDIA_OK:
            self.video_widget = QVideoWidget()
            self.media_player = QMediaPlayer(self)
            self.audio_output = QAudioOutput(self)
            self.media_player.setVideoOutput(self.video_widget)
            self.media_player.setAudioOutput(self.audio_output)
            video_layout.addWidget(self.video_widget, 1)

            controls = QHBoxLayout()
            self.play_button = QPushButton("⏸ Pause")
            self.play_button.setCursor(Qt.PointingHandCursor)
            self.play_button.clicked.connect(self._toggle_video_playback)
            controls.addWidget(self.play_button)
            controls.addStretch()
            video_layout.addLayout(controls)
        else:
            self.video_widget = None
            self.media_player = None
            no_video = QLabel(
                "Lecture vidéo indisponible (QtMultimedia manquant)."
            )
            no_video.setStyleSheet(f"color:{_TEXT_MUTED};")
            no_video.setAlignment(Qt.AlignCenter)
            video_layout.addWidget(no_video)

        self.stage.addWidget(video_page)
        content_layout.addWidget(self.stage, 1)

        # --- Navigation precedent / suivant + position -------------------
        nav_row = QHBoxLayout()
        self.prev_button = QPushButton("◀ Précédent")
        self.prev_button.setCursor(Qt.PointingHandCursor)
        self.prev_button.clicked.connect(self._go_prev)

        self.position_label = QLabel("")
        self.position_label.setAlignment(Qt.AlignCenter)
        self.position_label.setStyleSheet(f"color:{_TEXT_MUTED};")

        self.next_button = QPushButton("Suivant ▶")
        self.next_button.setCursor(Qt.PointingHandCursor)
        self.next_button.clicked.connect(self._go_next)

        nav_row.addWidget(self.prev_button)
        nav_row.addWidget(self.position_label, 1)
        nav_row.addWidget(self.next_button)
        content_layout.addLayout(nav_row)

        # --- Legende -------------------------------------------------------
        if CREDITS_EDIT_MODE:
            self.caption_edit = QTextEdit()
            self.caption_edit.setPlaceholderText("Ajouter une légende à cette photo/vidéo…")
            self.caption_edit.setFixedHeight(56)
            self.caption_edit.setStyleSheet(
                f"background-color:{_BG}; color:{_TEXT}; border:1px solid {_BORDER}; "
                f"border-radius:8px; padding:6px;"
            )
            content_layout.addWidget(self.caption_edit)

            save_row = QHBoxLayout()
            save_row.addStretch()
            self.save_caption_button = QPushButton("Enregistrer la légende")
            self.save_caption_button.setCursor(Qt.PointingHandCursor)
            self.save_caption_button.clicked.connect(self._save_current_caption)
            save_row.addWidget(self.save_caption_button)
            content_layout.addLayout(save_row)

            self.caption_label = None
        else:
            self.caption_edit = None
            self.caption_label = QLabel("")
            self.caption_label.setWordWrap(True)
            self.caption_label.setStyleSheet(f"color:{_TEXT}; font-style: italic;")
            content_layout.addWidget(self.caption_label)

        outer.addWidget(content, 1)

        # --- Statut ---------------------------------------------------------
        self.status_label = QLabel(
            "Ouvre l'onglet Crédits pour charger la collection." if self._root
            else "Dossier « credit_du_logiciel » introuvable à côté du projet."
        )
        self.status_label.setStyleSheet(f"color:{_TEXT_MUTED}; font-size:11px;")
        outer.addWidget(self.status_label)

        self._set_nav_enabled(False)

    # ------------------------------------------------------------------
    # CHARGEMENT ASYNCHRONE DES IMAGES (thread persistant)
    # ------------------------------------------------------------------

    def _start_image_loader(self):
        self._image_thread = QThread(self)
        self._image_worker = _ImageLoaderWorker()
        self._image_worker.moveToThread(self._image_thread)

        self.requestImageLoad.connect(self._image_worker.load)
        self._image_worker.imageReady.connect(self._on_image_ready)
        self._image_worker.failed.connect(self._on_pixmap_failed)

        self._image_thread.start()

    def shutdown(self):
        """A appeler depuis MainWindow.closeEvent pour arreter proprement
        les threads d'arriere-plan de la page Credits."""
        if self.media_player is not None:
            try:
                self.media_player.stop()
            except Exception:
                pass
        for thread in (self._scan_thread, self._image_thread):
            if thread is None:
                continue
            try:
                if thread.isRunning():
                    thread.quit()
                    thread.wait(2000)
            except RuntimeError:
                # Le thread de scan est detruit (deleteLater) des que le
                # scan est termine : rien a arreter, on passe au suivant
                # sans laisser cette exception bloquer l'arret du thread
                # de chargement d'images (persistant, lui).
                continue

    # ------------------------------------------------------------------
    # OUVERTURE PARESSEUSE (appelee par MainWindow au premier clic sur
    # l'onglet "Crédits" — le scan ne demarre pas avant)
    # ------------------------------------------------------------------

    def ensure_loaded(self):
        if self._loaded_once or self._scanning:
            return
        self._loaded_once = True
        self._start_scan()

    # ------------------------------------------------------------------
    # SCAN DU DOSSIER
    # ------------------------------------------------------------------

    def _start_scan(self):
        if self._root is None:
            self.status_label.setText(
                "Dossier « credit_du_logiciel » introuvable à côté du projet."
            )
            return
        if self._scanning:
            return

        self._scanning = True
        self.refresh_button.setEnabled(False)
        self.status_label.setText("Chargement de la collection en arrière-plan…")

        self._scan_thread = QThread(self)
        self._scan_worker = _AlbumScanWorker(self._root)
        self._scan_worker.moveToThread(self._scan_thread)
        self._scan_thread.started.connect(self._scan_worker.run)
        self._scan_worker.finished.connect(self._on_scan_finished)
        self._scan_worker.finished.connect(self._scan_thread.quit)
        self._scan_thread.finished.connect(self._scan_thread.deleteLater)
        self._scan_thread.start()

    def _on_scan_finished(self, albums, captions, error):
        self._scanning = False
        self.refresh_button.setEnabled(True)

        if error:
            self.status_label.setText(f"Erreur pendant le chargement : {error}")
            return

        self._albums = albums
        self._captions = captions
        self._pixmap_cache.clear()

        if not albums:
            self.status_label.setText(
                "Aucune photo ni vidéo trouvée dans « credit_du_logiciel »."
            )
            self.subtitle_label.setText("")
            self._set_nav_enabled(False)
            return

        n_items = sum(len(a["items"]) for a in albums)
        self.subtitle_label.setText(
            f"{len(albums)} dossier(s) — {n_items} photo(s)/vidéo(s)"
        )
        self.status_label.setText("Collection chargée.")

        self._build_tabs()
        self._set_nav_enabled(True)
        self._go_to(0, 0)

    def _build_tabs(self):
        while self.tabs_layout.count() > 1:
            item = self.tabs_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        self._tab_buttons = []

        for index, album in enumerate(self._albums):
            button = QToolButton()
            button.setText(f"{album['label']} ({len(album['items'])})")
            button.setCheckable(True)
            button.setAutoExclusive(True)
            button.setCursor(Qt.PointingHandCursor)
            button.setStyleSheet(
                "QToolButton { color:%s; background-color: transparent; "
                "border: 1px solid %s; border-radius: 10px; padding: 6px 12px; }"
                "QToolButton:checked { background-color: %s; color: #0b1219; "
                "border-color: %s; font-weight: 600; }"
                % (_TEXT, _BORDER, _ACCENT, _ACCENT)
            )
            button.clicked.connect(lambda checked=False, i=index: self._go_to(i, 0))
            self.tabs_layout.insertWidget(index, button)
            self._tab_buttons.append(button)

    # ------------------------------------------------------------------
    # NAVIGATION
    # ------------------------------------------------------------------

    def _set_nav_enabled(self, enabled: bool):
        self.prev_button.setEnabled(enabled)
        self.next_button.setEnabled(enabled)

    def _go_to(self, album_index: int, item_index: int):
        if not self._albums:
            return
        album_index %= len(self._albums)
        items = self._albums[album_index]["items"]
        if not items:
            return
        item_index %= len(items)

        self._album_index = album_index
        self._item_index = item_index

        if 0 <= album_index < len(self._tab_buttons):
            self._tab_buttons[album_index].setChecked(True)

        self._show_current()
        self._prefetch_next()

    def _go_next(self):
        if not self._albums:
            return
        album = self._albums[self._album_index]
        if self._item_index + 1 < len(album["items"]):
            self._go_to(self._album_index, self._item_index + 1)
        else:
            next_album = (self._album_index + 1) % len(self._albums)
            if next_album == 0:
                self.status_label.setText(
                    "Fin de la collection — retour au début."
                )
            self._go_to(next_album, 0)

    def _go_prev(self):
        if not self._albums:
            return
        if self._item_index > 0:
            self._go_to(self._album_index, self._item_index - 1)
        else:
            prev_album = (self._album_index - 1) % len(self._albums)
            last_index = len(self._albums[prev_album]["items"]) - 1
            self._go_to(prev_album, last_index)

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key_Right, Qt.Key_Down, Qt.Key_Space):
            self._go_next()
            return
        if event.key() in (Qt.Key_Left, Qt.Key_Up):
            self._go_prev()
            return
        super().keyPressEvent(event)

    # ------------------------------------------------------------------
    # AFFICHAGE DE L'ELEMENT COURANT
    # ------------------------------------------------------------------

    def _current_item(self):
        album = self._albums[self._album_index]
        return album, album["items"][self._item_index]

    def _caption_key(self, album_key: str, item_name: str) -> str:
        return f"{album_key}/{item_name}"

    def _show_current(self):
        if self.media_player is not None:
            self.media_player.stop()

        album, item = self._current_item()
        total = len(album["items"])
        self.position_label.setText(
            f"{album['label']} — {self._item_index + 1}/{total}"
        )

        caption_key = self._caption_key(album["key"], item["name"])
        caption_text = self._captions.get(caption_key, "")
        if CREDITS_EDIT_MODE:
            self.caption_edit.blockSignals(True)
            self.caption_edit.setPlainText(caption_text)
            self.caption_edit.blockSignals(False)
        else:
            self.caption_label.setText(caption_text)
            self.caption_label.setVisible(bool(caption_text))

        if item["type"] == "video":
            self.stage.setCurrentIndex(1)
            if self.media_player is not None:
                from PySide6.QtCore import QUrl
                self.media_player.setSource(QUrl.fromLocalFile(item["path"]))
                self.media_player.play()
                self.play_button.setText("⏸ Pause")
            return

        # Image : cache d'abord, sinon demande de chargement en arriere-plan.
        self.stage.setCurrentIndex(0)
        cache_key = (album["key"], self._item_index)
        cached = self._pixmap_cache.get(cache_key)
        if cached is not None:
            self._display_pixmap(cached)
        else:
            self.image_label.setText("Chargement…")
            self.image_label.setStyleSheet(f"color:{_TEXT_MUTED}; background: transparent;")
            self._request_seq += 1
            self.requestImageLoad.emit(
                album["key"], self._item_index, self._request_seq, item["path"]
            )

    def _prefetch_next(self):
        """Charge en tache de fond l'image suivante, sans l'afficher,
        pour que le clic sur "Suivant" paraisse instantane."""
        if not self._albums:
            return
        album = self._albums[self._album_index]
        if self._item_index + 1 < len(album["items"]):
            next_album, next_index = album, self._item_index + 1
        else:
            next_album_idx = (self._album_index + 1) % len(self._albums)
            next_album = self._albums[next_album_idx]
            next_index = 0

        if not next_album["items"]:
            return
        next_item = next_album["items"][next_index]
        if next_item["type"] != "image":
            return
        cache_key = (next_album["key"], next_index)
        if cache_key in self._pixmap_cache:
            return
        self._request_seq += 1
        self.requestImageLoad.emit(
            next_album["key"], next_index, self._request_seq, next_item["path"]
        )

    def _remember_pixmap(self, album_key, item_index, pixmap):
        cache_key = (album_key, item_index)
        self._pixmap_cache[cache_key] = pixmap
        self._pixmap_cache.move_to_end(cache_key)
        while len(self._pixmap_cache) > _MAX_PIXMAP_CACHE:
            self._pixmap_cache.popitem(last=False)

    def _on_image_ready(self, album_key, item_index, request_id, image):
        # Conversion QImage -> QPixmap ici, sur le thread GUI : c'est la
        # seule etape non sure a faire depuis le thread de chargement.
        pixmap = QPixmap.fromImage(image)
        self._remember_pixmap(album_key, item_index, pixmap)

        if not self._albums:
            return
        current_album = self._albums[self._album_index]
        is_current = (
            current_album["key"] == album_key and item_index == self._item_index
        )
        if is_current and self.stage.currentIndex() == 0:
            self._display_pixmap(pixmap)

    def _on_pixmap_failed(self, album_key, item_index, request_id, message):
        if not self._albums:
            return
        current_album = self._albums[self._album_index]
        is_current = (
            current_album["key"] == album_key and item_index == self._item_index
        )
        if is_current:
            self.image_label.setText(f"Impossible d'afficher ce fichier : {message}")

    def _display_pixmap(self, pixmap: QPixmap):
        target = self.image_label.size()
        if target.width() < 10 or target.height() < 10:
            target = QSize(_MAX_IMG_W, _MAX_IMG_H)
        scaled = pixmap.scaled(target, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.image_label.setPixmap(scaled)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self.stage.currentIndex() != 0 or not self._albums:
            return
        album = self._albums[self._album_index]
        cache_key = (album["key"], self._item_index)
        cached = self._pixmap_cache.get(cache_key)
        if cached is not None:
            self._display_pixmap(cached)

    # ------------------------------------------------------------------
    # VIDEO
    # ------------------------------------------------------------------

    def _toggle_video_playback(self):
        if self.media_player is None:
            return
        if self.media_player.playbackState() == QMediaPlayer.PlayingState:
            self.media_player.pause()
            self.play_button.setText("▶ Lecture")
        else:
            self.media_player.play()
            self.play_button.setText("⏸ Pause")

    # ------------------------------------------------------------------
    # LEGENDES
    # ------------------------------------------------------------------

    def _save_current_caption(self):
        if not CREDITS_EDIT_MODE or not self._albums or self._root is None:
            return
        album, item = self._current_item()
        key = self._caption_key(album["key"], item["name"])
        text = self.caption_edit.toPlainText().strip()

        if text:
            self._captions[key] = text
        else:
            self._captions.pop(key, None)

        try:
            captions_path = self._root / CAPTIONS_FILENAME
            captions_path.write_text(
                json.dumps(self._captions, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            self.status_label.setText("Légende enregistrée.")
        except Exception as exc:
            self.status_label.setText(f"Échec de l'enregistrement de la légende : {exc}")
